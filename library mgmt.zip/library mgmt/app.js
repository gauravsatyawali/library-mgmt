const books = [{
    name: "Rudest Book Ever",
    author: "Shwetabh Gangwar",
    bookPages: 200,
    bookPrice: 240,
    bookState: "Available"
},
{
    name: "Do Epic Shit",
    author: "Ankur Wariko",
    bookPages: 200,
    bookPrice: 240,
    bookState: "Available"
},
{ id: 1, name: "Do Epic Shit 1", author: "Ankur Wariko", bookPages: 200, bookPrice: 240, bookState: "Available" },
{ id: 2, name: "The Art of War 2", author: "Sun Tzu", bookPages: 150, bookPrice: 180, bookState: "Available" },
{ id: 3, name: "1984 3", author: "George Orwell", bookPages: 328, bookPrice: 220, bookState: "Available" },
{ id: 4, name: "To Kill a Mockingbird 4", author: "Harper Lee", bookPages: 281, bookPrice: 250, bookState: "Available" },
{ id: 5, name: "Pride and Prejudice 5", author: "Jane Austen", bookPages: 279, bookPrice: 270, bookState: "Available" },
{ id: 6, name: "The Catcher in the Rye 6", author: "J.D. Salinger", bookPages: 214, bookPrice: 200, bookState: "Available" },
{ id: 7, name: "The Great Gatsby 7", author: "F. Scott Fitzgerald", bookPages: 180, bookPrice: 240, bookState: "Available" },
{ id: 8, name: "Moby-Dick 8", author: "Herman Melville", bookPages: 635, bookPrice: 300, bookState: "Available" },
{ id: 9, name: "War and Peace 9", author: "Leo Tolstoy", bookPages: 1225, bookPrice: 400, bookState: "Available" },
{ id: 10, name: "Crime and Punishment 10", author: "Fyodor Dostoevsky", bookPages: 671, bookPrice: 350, bookState: "Avalilable" },
{ id: 11, name: "The Odyssey 11", author: "Homer", bookPages: 541, bookPrice: 280, bookState: "Available" },
{ id: 12, name: "The Iliad 12", author: "Homer", bookPages: 704, bookPrice: 300, bookState: "Available" },
{ id: 13, name: "Ulysses 13", author: "James Joyce", bookPages: 730, bookPrice: 320, bookState: "Available" },
{ id: 14, name: "The Divine Comedy 14", author: "Dante Alighieri", bookPages: 798, bookPrice: 340, bookState: "Available" },
{ id: 15, name: "The Brothers Karamazov 15", author: "Fyodor Dostoevsky", bookPages: 796, bookPrice: 380, bookState: "Available" },
{ id: 16, name: "One Hundred Years of Solitude 16", author: "Gabriel Garcia Marquez", bookPages: 417, bookPrice: 260, bookState: "Available" },
{ id: 17, name: "Moby-Dick 17", author: "Herman Melville", bookPages: 635, bookPrice: 300, bookState: "Available" },
{ id: 18, name: "Anna Karenina 18", author: "Leo Tolstoy", bookPages: 864, bookPrice: 360, bookState: "Available" },
{ id: 19, name: "Madame Bovary 19", author: "Gustave Flaubert", bookPages: 329, bookPrice: 230, bookState: "Available" },
{ id: 20, name: "Don Quixote 20", author: "Miguel de Cervantes", bookPages: 992, bookPrice: 380, bookState: "Available" },
{ id: 21, name: "The Hobbit 21", author: "J.R.R. Tolkien", bookPages: 310, bookPrice: 240, bookState: "Available" },
{ id: 22, name: "The Lord of the Rings 22", author: "J.R.R. Tolkien", bookPages: 1178, bookPrice: 400, bookState: "Available" },
{ id: 23, name: "Catch-22 23", author: "Joseph Heller", bookPages: 453, bookPrice: 260, bookState: "Available" },
{ id: 24, name: "Beloved 24", author: "Toni Morrison", bookPages: 324, bookPrice: 220, bookState: "Available" },
{ id: 25, name: "The Sound and the Fury 25", author: "William Faulkner", bookPages: 326, bookPrice: 250, bookState: "Available" },
{ id: 26, name: "The Grapes of Wrath 26", author: "John Steinbeck", bookPages: 464, bookPrice: 280, bookState: "Available" },
{ id: 27, name: "Brave New World 27", author: "Aldous Huxley", bookPages: 311, bookPrice: 230, bookState: "Available" },
{ id: 28, name: "Jane Eyre 28", author: "Charlotte Bronte", bookPages: 500, bookPrice: 270, bookState: "Available" },
{ id: 29, name: "Wuthering Heights 29", author: "Emily Bronte", bookPages: 416, bookPrice: 240, bookState: "Available" },
{ id: 30, name: "The Picture of Dorian Gray 30", author: "Oscar Wilde", bookPages: 254, bookPrice: 200, bookState: "Available" },
{ id: 31, name: "The Adventures of Huckleberry Finn 31", author: "Mark Twain", bookPages: 366, bookPrice: 220, bookState: "Available" },
{ id: 32, name: "Frankenstein 32", author: "Mary Shelley", bookPages: 280, bookPrice: 210, bookState: "Available" },
{ id: 33, name: "Dracula 33", author: "Bram Stoker", bookPages: 418, bookPrice: 230, bookState: "Available" },
{ id: 34, name: "The Shining 34", author: "Stephen King", bookPages: 447, bookPrice: 260, bookState: "Available" },
{ id: 35, name: "It 35", author: "Stephen King", bookPages: 1138, bookPrice: 400, bookState: "Available" },
{ id: 36, name: "The Alchemist 36", author: "Paulo Coelho", bookPages: 208, bookPrice: 200, bookState: "Available" },
{ id: 37, name: "Sapiens 37", author: "Yuval Noah Harari", bookPages: 498, bookPrice: 300, bookState: "Available" },
{ id: 38, name: "Educated 38", author: "Tara Westover", bookPages: 352, bookPrice: 260, bookState: "Available" },
{ id: 39, name: "Becoming 39", author: "Michelle Obama", bookPages: 448, bookPrice: 280, bookState: "Available" },
{ id: 40, name: "The Power of Habit 40", author: "Charles Duhigg", bookPages: 371, bookPrice: 250, bookState: "Available" },
{ id: 41, name: "Thinking, Fast and Slow 41", author: "Daniel Kahneman", bookPages: 499, bookPrice: 300, bookState: "Available" },
{ id: 42, name: "Atomic Habits 42", author: "James Clear", bookPages: 320, bookPrice: 240, bookState: "Available" },
{ id: 43, name: "The Subtle Art of Not Giving a F*ck 43", author: "Mark Manson", bookPages: 224, bookPrice: 220, bookState: "Available" },
{ id: 44, name: "Grit 44", author: "Angela Duckworth", bookPages: 352, bookPrice: 260, bookState: "Available" },
{ id: 45, name: "The Lean Startup 45", author: "Eric Ries", bookPages: 336, bookPrice: 240, bookState: "Available" },
{ id: 46, name: "Zero to One 46", author: "Peter Thiel", bookPages: 210, bookPrice: 220, bookState: "Available" }
]


const exp = require('constants')
let express = require('express')
let app = express()
let path = require('path')

app.set('view engine', 'ejs')
app.use(express.static(path.join(__dirname, 'public')))
app.use(express.urlencoded({ extended: true }))


app.get('/', (req, res) => {
    res.render('login')
})
app.get('/login', (req, res) => {
    res.render('login')
})
app.post('/login', (req, res) => {
    let email = req.body.email
    let password = req.body.password
    if(email=='nohara@siro.com' && password=='sinchan7'){
        res.render('index',{data:books})
    }

})
app.get('/signup', (req, res) => {
    res.render('signup')
})

app.get('/books', (req, res) => {
    res.render('books',{data:books})
})
app.post('/add', (req, res) => {
    let name = req.body.name
    let author = req.body.author
    if (name == "" && author == "") {

        res.render('index', { data: books })
    }
    else {
        books.push({ name, author, bookState: 'Available' })
        res.render('index', { data: books })
    }
})

app.post('/delete', (req, res) => {
    let name = req.body.name
    let j = 0
    books.forEach(element => {
        j++
        if (name == element.name) {
            books.splice(j - 1, 1)
        }
    })
    res.render('index', { data: books })
})

app.post('/issue', (req, res) => {
    let name = req.body.name
    books.forEach(element => {
        if (name == element.name) {
            element.bookState = 'Issued'
        }
    })
    res.render('index', { data: books })
})
app.post('/return', (req, res) => {
    let name = req.body.name
    books.forEach(element => {
        if (name == element.name) {
            element.bookState = 'Available'
        }
    })
    res.render('index', { data: books })
})

app.listen(3000)