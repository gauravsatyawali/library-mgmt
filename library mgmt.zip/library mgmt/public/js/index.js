// console.log("hell0")

// //Book constructor
// function book(name, author) {
//     this.name = name
//     this.author = author
// }

// //Display constructor
// function display() {

// }
// // display prototype
// display.prototype.add = function (Book){
//     let name = Book.name
//     let author = Book.author
//     let tbody = document.getElementById('tbody')
//     let string= `
//     <tr class="h-10">
//                     <td>${name}</td>
//                     <td>${author}</td>
//                     <td>none</td>
//                   </tr>
//     `
//     tbody.innerHTML += string
// }

// display.prototype.clear = function(){
//     let form = document.getElementById("lib-form")
//     form.reset()
// }

//form submit
// let submit = document.getElementById("lib-form")
// submit.addEventListener("submit", (e) => {
//     // e.preventDefault()
//     let name = document.getElementById('name').value
//     let author = document.getElementById('author').value
    
//     if (name == "" && author == "") {
//         return
//     }
//     let Book = new book(name, author)
//     console.log(Book)
    
//     let Display = new display()
//     Display.add(Book)
//     Display.clear()
    
// })
